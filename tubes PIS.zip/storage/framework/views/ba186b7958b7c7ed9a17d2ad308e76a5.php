  
<?php $__env->startSection('title', 'Detail Data'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Detail Data Mahasiswa</h1>
    <hr />
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">NIM</label>
            <input type="text" name="title" class="form-control" placeholder="NIM" value="<?php echo e($mahasiswa->NIM); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Nama Mahasiswa </label>
            <input type="text" name="Nama" class="form-control" placeholder="Nama" value="<?php echo e($mahasiswa->Nama); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Nama Ayah</label>
            <input type="text" name="Nama_Ayah" class="form-control" placeholder="Nama Ayah" value="<?php echo e($mahasiswa->Nama_Ayah); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Nama Ibu</label>
            <input type="text" name="Nama_Ibu" class="form-control" placeholder="Nama Ibu" value="<?php echo e($mahasiswa->Nama_Ibu); ?>" readonly>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Alamat Mahasiswa</label>
            <textarea class="form-control" name="Alamat" placeholder="Alamat Mahasiswa" readonly><?php echo e($mahasiswa->Alamat); ?></textarea>
        </div>
    </div>
    <div class="row">
        <div class="col mb-3">
            <label class="form-label">Created At</label>
            <input type="text" name="created_at" class="form-control" placeholder="Created At" value="<?php echo e($mahasiswa->created_at); ?>" readonly>
        </div>
        <div class="col mb-3">
            <label class="form-label">Updated At</label>
            <input type="text" name="updated_at" class="form-control" placeholder="Updated At" value="<?php echo e($mahasiswa->updated_at); ?>" readonly>
        </div>
    </div>
    <div class="mt-3 text-left">
        <a href="<?php echo e(route('dataMahasiswa')); ?>" id="btn-kembali" class="btn btn-secondary">Kembali</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/dataMahasiswa/show.blade.php ENDPATH**/ ?>