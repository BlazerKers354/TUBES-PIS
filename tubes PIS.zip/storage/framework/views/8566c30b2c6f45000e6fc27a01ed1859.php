  
<?php $__env->startSection('title', 'Input Data'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Tambah Data Mahasiswa</h1>
    <hr />
    <form action="<?php echo e(route('dataMahasiswa.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="NIM" class="form-control" placeholder="NIM">
            </div>
            <div class="col">
                <input type="text" name="Nama_Ayah" class="form-control" placeholder="Nama Ayah">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col">
                <input type="text" name="Nama" class="form-control" placeholder="Nama Mahasiswa">
            </div>
            <div class="col">
                <input type="text" name="Nama_Ibu" class="form-control" placeholder="Nama Ibu">
            </div>
        </div>

        <div class="row mb-3">
            <div class="col">
                <input type="text" name="Alamat" class="form-control" placeholder="Alamat Mahasiswa">
            </div>
        </div>
 
        <div class="mt-5 text-left">
        <button id="btn" class="btn btn-success" type="submit">Simpan Data</button>
        <a href="<?php echo e(route('dataMahasiswa')); ?>" id="btn-kembali" class="btn btn-secondary ml-3">Kembali</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/dataMahasiswa/create.blade.php ENDPATH**/ ?>