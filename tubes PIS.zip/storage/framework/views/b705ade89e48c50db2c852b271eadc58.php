<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>Copyright | Zulfa Azka Farisadilah</span>
    </div>
  </div>
</footer><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/layouts/footer.blade.php ENDPATH**/ ?>