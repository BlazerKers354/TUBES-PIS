  
<?php $__env->startSection('title', 'Edit Data'); ?>
  
<?php $__env->startSection('contents'); ?>
    <h1 class="mb-0">Edit Data Mahasiswa</h1>
    <hr />
    <form action="<?php echo e(route('dataMahasiswa.update', $mahasiswa->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">NIM</label>
                <input type="text" name="NIM" class="form-control" placeholder="NIM" value="<?php echo e($mahasiswa->NIM); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Nama Mahasiswa</label> 
                <input type="text" name="Nama" class="form-control" placeholder="Nama Mahasiswa" value="<?php echo e($mahasiswa->Nama); ?>" >
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Nama Ayah</label>
                <input type="text" name="Nama_Ayah" class="form-control" placeholder="Nama Ayah" value="<?php echo e($mahasiswa->Nama_Ayah); ?>" >
            </div>
            <div class="col mb-3">
                <label class="form-label">Nama Ibu</label>
                <input type="text" name="Nama_Ibu" class="form-control" placeholder="Nama Ibu" value="<?php echo e($mahasiswa->Nama_Ibu); ?>" >
            </div>
        </div>
        <div class="row">
            <div class="col mb-3">
                <label class="form-label">Alamat</label>
                <textarea class="form-control" name="Alamat" placeholder="Alamat Mahasiswa" ><?php echo e($mahasiswa->Alamat); ?></textarea>
            </div>
        </div>
        <div class="mt-3 text-left">
            <button type="submit" class="btn btn-info">Perbarui</button>
            <a href="<?php echo e(route('dataMahasiswa')); ?>" id="btn-kembali" class="btn btn-secondary ml-3">Kembali</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/dataMahasiswa/edit.blade.php ENDPATH**/ ?>