<?php
namespace App\Http\Controllers;
use App\Models\Mahasiswa;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportController extends Controller
{
    public function mahasiswa()
    {
        $mahasiswa = Mahasiswa::all();
        $pdf = Pdf::loadView('reports.mahasiswa', compact('mahasiswa'));
        return $pdf->download('laporan_mahasiswa.pdf');
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Data Mahasiswa</title>
    <style>
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #000; padding: 8px; }
    </style>
</head>
<body>
    <h2>Laporan Data Mahasiswa</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Nama Ayah</th>
                <th>Nama Ibu</th>
                <th>Alamat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mhs->NIM); ?></td>
                <td><?php echo e($mhs->Nama); ?></td>
                <td><?php echo e($mhs->Nama_Ayah); ?></td>
                <td><?php echo e($mhs->Nama_Ibu); ?></td>
                <td><?php echo e($mhs->Alamat); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php ?><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/reports/mahasiswa.blade.php ENDPATH**/ ?>