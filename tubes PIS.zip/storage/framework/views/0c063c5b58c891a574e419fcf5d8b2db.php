  
<?php $__env->startSection('title', 'Data Mahasiswa'); ?>
  
<?php $__env->startSection('contents'); ?>
    <div class="d-flex align-items-center justify-content-between">
        <h1 class="mb-0">List Data Mahasiswa</h1>
        <a href="<?php echo e(route('dataMahasiswa.create')); ?>" class="btn btn-success">Tambah Data Mahasiswa</a>
    </div>
    <hr />
    <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(Session::get('success')); ?>

        </div>
    <?php endif; ?>


    <table class="table table-hover">
        <thead class="table-primary">
            <tr>
                <th>#</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Nama Ayah</th>
                <th>Nama Ibu</th>
                <th>Tindakan</th>
            </tr>
        </thead>
        <tbody>
            <?php if($mahasiswa->count() > 0): ?>
                <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                        <td class="align-middle"><?php echo e($mh->NIM); ?></td>
                        <td class="align-middle"><?php echo e($mh->Nama); ?></td>
                        <td class="align-middle"><?php echo e($mh->Alamat); ?></td>
                        <td class="align-middle"><?php echo e($mh->Nama_Ayah); ?></td>  
                        <td class="align-middle"><?php echo e($mh->Nama_Ibu); ?></td>  
                        <td class="align-middle">
                            <a href="<?php echo e(route('dataMahasiswa.show', $mh->id)); ?>" type="button" class="btn btn-primary">Detail</a>
                            <a href="<?php echo e(route('dataMahasiswa.edit', $mh->id)); ?>" type="button" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('dataMahasiswa.destroy', $mh->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td class="text-center" colspan="7">Data Mahasiswa Tidak Ditemukan</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\zulfa\OneDrive\Desktop\Tubes Implementasi Sistem\resources\views/dataMahasiswa/index.blade.php ENDPATH**/ ?>